/**
 * BAE System Web Application
 */
var app = angular.module('baeApp', ['ngRoute']);

app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    .when("/", {templateUrl: "partials/home.html", controller: "homeCtrl"})    
    .otherwise("/home", {templateUrl: "partials/home.html", controller: "homeCtrl"});
}]);

app.controller('homeCtrl', ['$scope', '$http', 'dataService', function ($scope, $http, dataService) {
	
	dataService.get().then(function (response) {
		var latitude = '3.100753', langtitude = '101.667495';
		
		$scope.data = response.data;
		var countries = [], cities = [];
		if(response.data.length > 0) {			
			angular.forEach(response.data, function(value, key) {
				if (countries.indexOf(value.country) === -1)
				this.push(value.country);
			}, countries);			
		}
		$scope.countries = countries;
		
		//Filter using country
		$scope.filterCountry = function() {
			$scope.markers = []; cities = [];
			var filteredData=[], i=0;
			if($scope.selCtry != '' && $scope.selCtry != null) {
				angular.forEach(response.data, function(value, key) {
					if(value.country == $scope.selCtry) {
						if(cities.indexOf(value.city) === -1) {
							cities.push(value.city);
						}						
						filteredData[i] = value;
						i++;
					}					
				});
				$scope.cities = cities;
			} else {
				filteredData = response.data;
			}

			$scope.mapOptions = {
				zoom: 12,
				center: new google.maps.LatLng(filteredData[0].lat, filteredData[0].lng),
				mapTypeId: google.maps.MapTypeId.TERRAIN
			}
			$scope.map = new google.maps.Map(document.getElementById('map'), $scope.mapOptions);
			
			for (i = 0; i < filteredData.length; i++){
				createMarker(filteredData[i]);
			}
			
		}
		
		
		//Filter using city
		$scope.filterCity = function() {
			$scope.markers = []; cities = [];
			var filteredData=[], i=0;
			if($scope.selCity != '' && $scope.selCity != null) {
				angular.forEach(response.data, function(value, key) {
					if(value.country == $scope.selCtry && value.city == $scope.selCity) {
						filteredData[i] = value;
						i++;
					}					
				});
			} else {
				i=0;
				angular.forEach(response.data, function(value, key) {
					if(value.country == $scope.selCtry) {						
						filteredData[i] = value;
						i++;
					}					
				});
			}
			
			$scope.mapOptions = {
				zoom: 12,
				center: new google.maps.LatLng(filteredData[0].lat, filteredData[0].lng),
				mapTypeId: google.maps.MapTypeId.TERRAIN
			}
			$scope.map = new google.maps.Map(document.getElementById('map'), $scope.mapOptions);			
			
			for (i = 0; i < filteredData.length; i++){
				createMarker(filteredData[i]);
			}
			
			
		}

		//Google map codeing start
		var mapOptions = {
			zoom: 12,
			center: new google.maps.LatLng(latitude, langtitude),
			mapTypeId: google.maps.MapTypeId.TERRAIN
		}
		$scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);
			
		$scope.markers = [];
		
		var infoWindow = new google.maps.InfoWindow();
		
		var createMarker = function (info){
			var marker = new google.maps.Marker({
				map: $scope.map,
				position: new google.maps.LatLng(info.lat, info.lng),
				title: info.city
			});
			marker.address = info.address;
			marker.country = info.country;
			
			marker.content = '<div class="infoWindowContent">' + info.address+ ' Pin Code: '+info.postalCode + '</div>';
			
			google.maps.event.addListener(marker, 'click', function(){
				infoWindow.setContent('<h2>' + marker.country+': '+marker.title + '</h2>' + marker.content);
				infoWindow.open($scope.map, marker);
			});
			$scope.markers.push(marker);	
		}  
		
		for (i = 0; i < $scope.data.length; i++){
			createMarker($scope.data[i]);
		}
		
		$scope.openInfoWindow = function(e, selectedMarker){
			e.preventDefault();
			google.maps.event.trigger(selectedMarker, 'click');
		}
		//Google map codeing end
	
    });
	
}]);

app.factory('dataService', ['$http', function ($http) {
    return {
        get: function () {
            console.log("inside function");
            return $http.get('data/location.json');
        }
    };
}]);